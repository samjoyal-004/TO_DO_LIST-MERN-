import TaskList from './components/TaskList';

const App = () => {
    return (
        <div>
            <TaskList />
        </div>
    );
};

export default App;
